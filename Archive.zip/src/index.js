import React from 'react';
import {createRoot} from 'react-dom/client';
import './index.css';
import Container from './Container';

const root = createRoot(document.getElementById('root'))

root.render(<Container />)