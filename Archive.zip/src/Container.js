import React from 'react'
import App from './App'

const Container = () => {
  return (
    <div>
      <App />
      <App listen={true}/>
    </div>
  )
}

export default Container