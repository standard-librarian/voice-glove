import { useEffect, useRef, useState } from 'react'
import { useSpeechRecognition } from 'react-speech-kit'
import hello from "./Hello.mp4";
import name from "./Name.mp4";
import my from "./My.mp4";
import idle from "./Idle.mp4"

function App(props) {
  const vidRef = useRef()
  const handlePlayPress = () => {
    if(props.listen)
    {
      vidRef.current.pause();
      vidRef.current.currentTime = 0;
      vidRef.current.muted = false;
      vidRef.current.loop = false;
      vidRef.current.play();
    }
  };
  
  
  const handleVideoEnded = () => {
    if(props.listen)
    {
      handlePlayPress()
      if(!vidRef.current.src.includes('Idle'))
      setVideo(idle)
    }
  };

  const [video, setVideo] = useState(idle)
  useEffect(() => {
    vidRef.current.src = video
  }, [video])
  const { listen, listening, stop, supported } = useSpeechRecognition({
    onResult: (result) => {
      if(props.listen)
      {
        if(result.split(' ').at(-1).toLowerCase() === 'hello')
          setVideo(hello)
        if(result.split(' ').at(-1).toLowerCase() === 'my')
          setVideo(my)
        if(result.split(' ').at(-1).toLowerCase() === 'name')
          setVideo(name)
        handlePlayPress()
      }
    },
  }) 
  return (
    <div className='app' style={{position: "absolute"}} onMouseEnter={() => props.listen ? listen() : ''}>
      <video 
      style={{transition: "ease-in-out"}}
      width={'100%'}
      height={'100%'}
        ref={vidRef}
        muted
        onEnded={handleVideoEnded}
        autoPlay
      >
          <source src={video} type="video/mp4"></source>
      </video>
    </div>
  )
}

export default App;
